

#ifndef TYPE_H
#define TYPE_H

    //type
enum PL_Type
{
	INTEGER=310, BOOLEAN, 
    UNIVERSAL
};

    //Kind
enum PL_Kind
{
	CONSTANT=305, VAR, ARR, 
    PROCEDURE, UNDEFINED
};


#endif
