
#ifndef ADMINISTRATION_H
#define ADMINISTRATION_H

#include <string>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <vector>
#include "token.h"
#include "scanner.h"
#include "blocktable.h"

// This is the maximum number of errors before the compiler bails out.
#define MAXERRORS 50
#define TERMINALS 47	

enum errorkind {ScanE, ParseE, ScopeE, TypeE};

using namespace std;

class Administration
{

	public:
	    //flag for printing symbol table
	bool printSymbolTable;
	
	Administration();
	
	~Administration() {}

	    // Begin a new line
	void NewLine();
	
        // Error function for the phases
	void error(errorkind , Symbol, int);
	
        //function for error count
	void ErrorCount();	

	// call scanner from here
	int scan();

	int lineNo;

	bool validTok(Symbol sym);

	static const string terminals[TERMINALS];


	void complete();

	private:

	bool correctline;

		//get token from scan() function	
	Token nextTok;

        //count the number of errors.
	int errorCount;

		
};

#endif
