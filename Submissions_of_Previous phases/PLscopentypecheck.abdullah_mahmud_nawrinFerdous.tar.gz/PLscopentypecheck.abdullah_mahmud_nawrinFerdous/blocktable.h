#ifndef BLOCKTABLE_H
#define BLOCKTABLE_H

#include <vector>
#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>
#include "type.h"
#define MAXBLOCKS 10
#define MAXDEFINITIONS 20

      using namespace std;

	typedef struct
	{
		int id;
		PL_Kind kind;
		PL_Type type;
		int size;
		int value;
	}TableEntry;

	class BlockTable
	{

		private:
	
		int blockLevel;
		//vector of block table	
		typedef vector<TableEntry> table;
		typedef vector<table> block;
		//vector of vector
		block myBlock;
		ofstream &outFile;
	

		public:
		//default constructor
		BlockTable(ofstream &out);
                //error is false if name matches on the block table, false otherwise
		~BlockTable(){};
                 //returns true if the current block doesn't contain same ID more than once, false otherwise
		bool define(int, PL_Kind, PL_Type, int, int);
                //True if ID is found in the current block, false otherwise
		bool error;
		bool search(int);
		TableEntry find(int, bool &);
		//new block
		void newBlock();
		//Defining array size
		void setArraySize(int,int);
		//index for name definitions
		int def;
		
	};

	#endif


