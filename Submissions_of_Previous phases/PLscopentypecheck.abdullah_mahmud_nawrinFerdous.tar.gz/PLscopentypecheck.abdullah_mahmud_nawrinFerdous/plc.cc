
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include "symbol.h"	
#include "scanner.h"
#include "administration.h"
#include "parser.h"
#include "symboltable.h"
#include "blocktable.h"



int main(int argc, char *argv[]) {
    
	    //source file object	
	ifstream srcFile;

    	//output file object
	ofstream outFile;
        ofstream outFile1;
    	//print symbol table upon user input
	bool printSymTab = false;

	
	if(argc < 2)
	{
		cout<<"Missing input file name."<<endl;
		exit(0);
	}
	
	    //create a symbol table object
	Symboltable st;

	    //create a Scanner object
	Scanner scanner(srcFile,st);
	
	srcFile.open(argv[1]);
	outFile.open("ParserOutFile");
        outFile1.open("BlockOutFile");
	BlockTable bTable(outFile1);
	    //Parser calss object	

	Parser parser(srcFile, outFile, scanner, bTable);
    	//Strat Parsing  
	parser.program(ENDOFFILE);	
	
	srcFile.close();

	outFile.close();
}
