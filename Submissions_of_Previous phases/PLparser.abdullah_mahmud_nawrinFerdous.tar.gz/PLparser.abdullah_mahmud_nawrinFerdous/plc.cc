#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include "symbol.h"	
#include "scanner.h"
#include "administration.h"
#include "parser.h"
#include "symboltable.h"

int main(int argc, char *argv[]) {
    
	    //source file object	
	ifstream srcFile;

	    //output file object
	ofstream outFile;

	    //print symbol table upon user input
	bool printSymTab = false;
	
	    //At list two arguments are required while executing program
	if(argc < 2)
	{
		cout<<"Missing input file name."<<endl;
		exit(0);
	}
	
	    //create a symbol table object
	Symboltable st;

	    //create a Scanner object
	Scanner scanner(srcFile,st);
	
	srcFile.open(argv[1]);
	outFile.open("ParserOutFile");

	    //create a Parser calss object	
	Parser parser(srcFile, outFile, scanner);
	
        //Parsing starts from here  
	parser.program(ENDOFFILE);	
	
	srcFile.close();
	outFile.close();
}
