

#ifndef SYMBOLTABLE_H
#define SYMBOLTABLE_H

#include <iostream>
#include <vector>
#include <string>
#include "token.h"
#include "symbol.h"
#define KEYWORDS 17

    //using prime number to avoid collison in the distribution of keys in hash table
#define SYMTABLESIZE 307

using namespace std;

class Symboltable
{

	private:

        //defining hash table to store tokens
	vector<Token> htable;

        //using a simple linear probing function to map between token and key 
	int hashfn(string lex); 

        // to check occupied cells in hash table
	int occupied;
        
        //position returned by hashfn
	int position;
		
	
	public:

    static const string keywords[KEYWORDS]; 	

	    // default constructor to initialize symbol table and preload with reserve keywords
	Symboltable();

        //insert function to insert token known as reserve keywords
	void insert(Token tok);

        // Insert Identifier (ID) in the symbol table
        //also checks if the cell in hashtable is empty or not
	int insert(string s,int type);

        // Search for a lexeme, return its position if found or -1 if not.
	int find(string lex);
	        
	    // Checking if the hashtable is full or not 
	bool full();

   	    // Return total occupied cells
	int getOC();

       //Show symbol table 
	void print();

       // Calling destructor

	~Symboltable(){}
		
};

#endif


