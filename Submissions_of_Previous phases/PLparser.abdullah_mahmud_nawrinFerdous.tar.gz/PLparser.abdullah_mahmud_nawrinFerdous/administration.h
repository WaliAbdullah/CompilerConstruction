
#ifndef ADMINISTRATION_H
#define ADMINISTRATION_H

#include <string>
#include <cstdlib>
#include <vector>
#include <fstream>
#include <iostream>
#include "token.h"
#include "scanner.h"


// This is the maximum number of errors before the compiler bails out.
#define MAXERRORS 20
#define TERMINALS 47	
enum errorkind {ScanE, ParseE, ScopeE, TypeE};
using namespace std;

class Administration
{	
	public:
	    //flag for printing symbol table
	bool printSymbolTable;
	    
	Administration();

	~Administration() {}

	    // Begin a new line
	void NewLine();

	    // call scanner from here
	int scan();
	    
        //either valid or invalid token 
	bool validTok(Symbol sym);

    	//string of array that contains name of all terminal symbols
    	//helps to show meaningful lexical and syntactical error messages
	static const string terminals[TERMINALS];

	int lineNo;

	    // Error function for the phases
	void error(errorkind , Symbol, int);

	    //function for error count
	void ErrorCount();	

    	//parsing done message
	void complete();

	private:

	bool correctline;

	  //get token from scan() function	
	Token nextTok;
	
	  //count the number of errors.
	int errorCount;

		
};

#endif
