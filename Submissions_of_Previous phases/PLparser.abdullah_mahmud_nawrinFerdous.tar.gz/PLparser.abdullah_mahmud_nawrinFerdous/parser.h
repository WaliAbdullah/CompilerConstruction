
#ifndef PARSER_H
#define PARSER_H

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <vector>
#include "administration.h"
#include "token.h"
#include "scanner.h"
#include "firstfollow.h"
	


// maximum errors before the compiler bails out.
#define MAXERRORS 20
//enum errorkind {ScanE, ParseE, ScopeE, TypeE};
using namespace std;

class Parser
{

	private:

	  //input file
	ifstream &srcFile;
	 //output file	
	ofstream &outFile;
	 //Scanner object 
	Scanner &scanner;
	 // object to call he first-follow methods
	Firstfollow ff;
         //total error count
	int errorCount;
	int lineNo;
	 // report error if correctline is true
	bool correctline;
	 //keep track wheather nextTok is currect or look ahead token
	bool islookAheadTok;
         //Vector for stop symbols
	vector<Symbol> stopSet;
         //get the next token to look-ahead	
	Token lookAheadTok;
         //Administration class object for line count and error display	
	Administration admin;
	 //gc2 flag
	bool agc;
	
	
	public:

	 // Scanner object as an input to parse with input and output file stream
	Parser(ifstream &in, ofstream &out, Scanner &sc);
	~Parser() {}
	 //Defining grammer rules using the following procedures
	 // program = block '.'
	void program(Symbol);
	 // block = 'begin' defnPart stmtPart 'end'
	void block(vector<Symbol>);
	 // defnPart = {definition';'}
	void definitionPart(vector<Symbol>);
	 // definition = constantDefinition | variableDefinition | procedureDefinition
	void definition(vector<Symbol>);
	 // variableDefinition = typeSymbol variableList | typeSymbol 'array' variableList'['constant']'
	void variableDefinition(vector<Symbol>);
	 // procedureDefinition = 'proc' procedureName block
	void procedureDefinition(vector<Symbol>);
          // constantDefinition = 'const' constName '='  constant;
	void constantDefinition(vector<Symbol>); 
          // stmtPart = {statement';'}
        void statementPart(vector<Symbol>);
	 // statement =readStatement | writeStatement |  ifStatement | assignmentStatement | doStatement |  emptyStatement  
	void statement(vector<Symbol>);
	 // readStatement = 'read' variableAccessList
	void readStatement(vector<Symbol>);
	 // writeStatement = 'write' expressionList  
	void writeStatement(vector<Symbol>);
          // assignmentStatement = variableAccessList ':=' expressionList
	void assignmentStatement(vector<Symbol>);
	 // ifStatement = 'if' guardedCommandList 'fi' 
	void ifStatement(vector<Symbol>);
	 // doStatement = 'do' guardedCommandList 'od'
	void doStatement(vector<Symbol>);
         // variableAccessList = variableAccess{','variableAccess}
	void variableAccessList(vector<Symbol>);
         // typeSymbol = 'integer' | 'Boolean'
	void typeSymbol(vector<Symbol>);
	// variableList = variableName {',' variableName}
	void variableList(vector<Symbol>);
	 // expressionList = expression {','expression}
	void expressionList(vector<Symbol>);
	 // guardedCommandList = guardedCommand{'[]'guardedCommand}
	void guardedCommandList(vector<Symbol>);
	 // guardedCommand = expression '->' statementPart
	void guardedCommand(vector<Symbol>);
	 // expression = primaryExpression{primaryOperator primaryExpression}	
	void expression(vector<Symbol>);
	 // primaryOperator = '&' | '|'
	void primaryOperator(vector<Symbol>);	
	 // primaryExpression = simpleExpression [relationalOperator simpleExpression]
	void primaryExpression(vector<Symbol>);
	 // relationalOperator = '<' | '=' | '>'	
	void relationalOperator(vector<Symbol>);
         // addingOperator = '+' | '-'
	void addingOperator(vector<Symbol>);
	 //helps to execute {addingOperator term}
	void addopTerm(vector<Symbol>);
         // multiplyingOperator = '*' | '/' | '\'
	void multiplyingOperator(vector<Symbol>);
	 // simpleExpression = ['-'] term {addingOperator term}
	void simpleExpression(vector<Symbol>);
	 // term = factor {multiplyingOperator factor}
	void term(vector<Symbol>);
	 // factor = constant | variableAccess | '('expression')' | '~' factor	
	void factor(vector<Symbol>);
	 // variableAccess = variableName [indexSelector]
	void variableAccess(vector<Symbol>);
	 // constant = numeral | booleanSymbol | constantName
	void constant(vector<Symbol>);
	 //Match terminal symbols for recursive descent parsing
	bool match(Symbol,vector<Symbol>);
	 //set of symbol
	bool in(vector<Symbol> );
	 // move to new line of input
	void NewLine();
	 //syntax error check and recovery
	void syntaxError(vector<Symbol>);
	void syntaxCheck(vector<Symbol>);
	 //look ahead token
	void lookAheadToken();
		
};
//vector<Symbol> operator+(vector<Symbol> set1, vector<Symbol> set2);
//vector<Symbol> operator+(vector<Symbol> stops, Symbol sym);

#endif

