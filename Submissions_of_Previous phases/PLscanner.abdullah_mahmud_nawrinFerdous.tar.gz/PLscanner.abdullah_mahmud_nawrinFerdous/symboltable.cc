
#include "symboltable.h"


const string Symboltable::keywords[KEYWORDS] = {"begin", "end", "const", "array", "integer", "Boolean", "proc", "skip", "read", "write", "call", "if", "do", "fi", "od", "false", "true"};


Symboltable::Symboltable()
:occupied(1)
{
	//enum constant for keyword BEGIN, starts at 286

	int sym = 286; 
	
	// hash table initializing

	htable.reserve(SYMTABLESIZE);
	for( int i = 0; i < SYMTABLESIZE; ++i )
        {
            
               htable.push_back(Token(NONAME,-1,"noname"));
 
        }
	
	//preloading 17 reserve keywords with sname and lexeme

	for(int i=0; i < 17; i++)
	{
		Symbol castEnum = (Symbol)sym;
		Token tok(castEnum,-1,keywords[i]);
		insert(tok);
		sym = sym + 1;
	}
}


//inserting reserve keywords into symbol table here

void Symboltable::insert(Token tok)
{
	
	//checks if position is occupied or not

	int isOccupied = find(tok.getLexeme());
                
	Token tk(tok.getSymbol(),-1,"");
	
	//if Not then insert token
	if(isOccupied == -1)
	{	
		
		htable.at(position) = tk;
		tk = htable.at(position);
		occupied++;
	}
	//position is occupied then go to the next position
	else
	{
		position++;
		while(1)
		{
						
			Token tempTk;
			tempTk = htable.at(position); 	
				
			
			//if next position is empty, insert token
                        //263 is constant for NONAME
			if(tempTk.getSymbol() == 263)
			{	

				htable.at(position) = tk;

				tk = htable.at(position);
				occupied++;
				break;	
				
			}
					
			else
			{
				//check the last position
				if(position > 400)
				{
					position = 0;
				}
			       
				else
                                 {
				        position++;
                                 }				
				
				
			}
		}
	}
	
}


//To insert ID in Symbol-table

int Symboltable::insert(string s)
{
	

 
	if(full()) return 2;	

        //checks if position is occupied or not
	int isOccupied = find(s);
		
	//If not, then perform insert
	if(isOccupied == -1)
	{	
		Token tk(ID,-1,s);		
		htable.at(position) = tk;
		tk = htable.at(position);
		occupied++;
		return 1;			
	}
	//position is occupied, perform insert into the returned position
	else
	{
		while(1)
		{
						
			Token tempTk;
			tempTk = htable.at(position); 	
				
			
			//if next position is empty, insert token
                        //263 is enum constant for NONAME
			if(tempTk.getSymbol() == 263)
			{	
				
				Token tk(ID,-1,s);
                             
				htable.at(position) = tk;

				tk = htable.at(position);

				occupied++;

			return 1;	
				
			}
			


			else
			{
							
				
                                 int sym = tempTk.getSymbol();
				
                                //Checking if ID falls into reserve keyword range

				if(sym >= 286  && s == keywords[sym - 286] )
				{
					return sym; 
				}		
                                //checking if ID already exists or not
                               		
				else if( s == tempTk.getLexeme())
                                 {
					return 1;

                                 } 			
				
				//if not last position reset
				else
				{
					if(position > 400)
					{
						position = 0;
					}

                                  // increase position to get the next index
			
					else
                                         {
						position=position+1;
                                         }				
				
				}
			}
		}
	}
	
}


//find function
int Symboltable::find(string lex)
{
	position = hashfn(lex);
	Token tkn;
		
	tkn = htable.at(position); 
	
	if(tkn.getSymbol() ==263)
           {
		return -1;
            }
 
	else
          {
		return position;					
	
	}
}



//hash function
int Symboltable::hashfn(string lex)
{
        int i;
	int asciiVal = 0;
	for(i = 0; i < lex.length(); i++)
	{
		asciiVal += int(lex.at(i)); 	
	}	
	
        asciiVal=asciiVal%401;

	return asciiVal;
	
}


//return true if table is full otherwise false;
bool Symboltable::full()
{
        if(occupied==SYMTABLESIZE)
        {
            return true;
        }
        else
         {

          return false;
       }
	
}


//return number of occupiend cells in symbol table
int Symboltable::getOC()
{
	return occupied;
}







//print symbol table
void Symboltable::print()
{
  
        cout << "Printing Symbol Table:" << endl;
	for(int i=0; i < htable.size(); i++)
	{
		Token tempTk;

		tempTk = htable.at(i); 	
                
                		
		if(tempTk.getSymbol() != 263)
		{
			cout<<"Index of the Symbol :"<<tempTk.getSymbol(); 
                         cout << "Lexeme of the Symbol:" << tempTk.getLexeme() << endl;
		}
	}
}

