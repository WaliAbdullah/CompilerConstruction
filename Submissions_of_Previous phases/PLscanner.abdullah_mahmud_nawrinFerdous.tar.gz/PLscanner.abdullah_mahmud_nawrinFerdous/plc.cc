#include <iostream>
#include <fstream>
#include "scanner.h"
#include "symboltable.h"
#include "administration.h"


int main(int argc, char *argv[]) {
    
	
        if(argc!=3)
        {
                 cout << "Usage: " << argv[0] << "PL_file Output_file" << endl;
                 return 0;

        }

        ifstream inputfile(argv[1]);

        if(!inputfile)
         {

            cerr << "PL_file " << argv[1] << " could not be opened" << endl;
            return 1;
         }

        ofstream outputfile(argv[2]);
        if(!outputfile)
        {

              cerr << "Output_file " << argv[2] << " could not be opened" << endl;
             return 1; 
           }
	   //create a symbol table
	Symboltable st;
	  //create a Scanner
	Scanner scanner(inputfile,st);
	  //Administrator Object (Starts the compiler)
	Administration compiler(inputfile, outputfile, scanner);
	
	int status = compiler.scan();

	if(status == 0)
		cout << "Scanning Successful"<<endl;
	else
		cout<<"Program contains scan error(s)"<<endl;

        return 0;
    	
}

