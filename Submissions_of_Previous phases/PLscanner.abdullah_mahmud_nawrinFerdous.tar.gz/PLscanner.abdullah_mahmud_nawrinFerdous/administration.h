#ifndef ADMINISTRATION_H
#define ADMINISTRATION_H

#include <string>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <vector>
#include "token.h"
#include "scanner.h"


// This is the maximum number of errors before the compiler bails out.
#define MAXERRORS 20
enum errorkind {ScanE, ParseE, ScopeE, TypeE};
using namespace std;

class Administration
{
        public:
	  //flag for printing symbol table
	bool printSymbolTable;
	  // Set up input and output files for scanning
	Administration(ifstream &in, ofstream &out, Scanner &sc);
	~Administration() {}
	  // Begin a new line of input
	void NewLine();
	  // Error function for the phases
	void error(string text);
	// call scanner from here
	int scan();
	  //either valid or invalid token 
	bool validTok(Symbol sym);

	private:
	  //source file
	ifstream &srcFile;
	  //output file	
	ofstream &outFile;
	  //Scanner object reference
	Scanner &scanner;
	int lineNo;
	  // report error only if correct line is true; prevents multiple/redundant error/line
	bool correctline;
	  //count the number of errors.
	int errorCount;
	  //get token from scan() function	
	Token nextTok;
	
		
};

#endif
