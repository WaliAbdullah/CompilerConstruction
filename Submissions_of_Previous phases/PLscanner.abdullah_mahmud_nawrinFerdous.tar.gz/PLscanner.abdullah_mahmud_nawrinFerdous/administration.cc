#include "administration.h"


Administration::Administration(ifstream &in, ofstream &out, Scanner &sc)
:srcFile(in),outFile(out),scanner(sc),printSymbolTable(false)
{
}

  //return true if token is valid otherwise false
bool Administration::validTok(Symbol sym)
{
    if(sym == NONAME || sym == BADNAME || sym == BADNUMERAL || sym == BADSYMBOL)
        return false;
    else
        return true;
}

  //checking new line
void Administration::NewLine()
{
    lineNo++;
    outFile << "\n" << "Line " << lineNo<< ":";
    
}

  //recording error message to file
void Administration::error(string text)
{
    
}

int Administration::scan()
{
		
	
	lineNo = 1;
	errorCount = 0;
	
	outFile<<"Line "<<lineNo<<":";
	while(1)
	{
		   //read token until EOF
          nextTok = scanner.getToken();
		if(nextTok.getSymbol() == ENDOFFILE)
		{
			outFile << "<" <<nextTok.getSymbol()<< ","<<nextTok.getValue()<<","<<nextTok.getLexeme()<<"> ";
			break;
		}
		// go to newline if not EOF
		else if(nextTok.getSymbol() == NEWLINE)
			NewLine();
		//gets valid token
		else if(validTok(nextTok.getSymbol()))
		{
			outFile<<"<"<<nextTok.getSymbol()<< ","<<nextTok.getValue()<<","<<nextTok.getLexeme()<<"> "; 
		}
			
		else
		{
			//bail out if reaches max error
			if(errorCount >= MAXERRORS)
			{
				cout<<"Error limit is Maximum. Bailing out\n";
				outFile<<"Scanner bailed out!!";
				srcFile.close();
				outFile.close();
				exit(0);
			}
			//printing specific error message
            if(nextTok.getSymbol()==NONAME)
            {
                // do nothing
            }
            else if(nextTok.getSymbol()==BADNAME)
            {
                outFile << "Error: Bad Name  ";
                errorCount++;
            }
            else if(nextTok.getSymbol()==BADNUMERAL)
            {
                outFile << "Error: Bad Numeral  ";
                errorCount++;
            }
            else if(nextTok.getSymbol()==BADSYMBOL)
            {
                outFile << "Error: Bad Symbol " ;
                errorCount++;
            }
            else
            {
                outFile << "Error: Bad Character" ;
            }
			
		}
	}
	//printing symbol table for user
	if(printSymbolTable)	
		scanner.printSymTable();
	srcFile.close();
	outFile.close();

	return errorCount;
}






